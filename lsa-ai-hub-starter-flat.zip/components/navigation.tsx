import Link from 'next/link';

const links = [
  { href: '/', label: 'Overview' },
  { href: '/divisions', label: 'Divisions' },
  { href: '/projects', label: 'Projects' },
  { href: '/reminders', label: 'Reminders' }
];

export function Navigation() {
  return (
    <header className="border-b border-green-100 bg-white/90 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 sm:px-6 lg:px-8">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-green-700">Lawn Solutions Australia</p>
          <h1 className="text-xl font-bold text-brand-dark">LSA AI Hub Starter</h1>
        </div>
        <nav className="flex gap-2 rounded-full border border-green-100 bg-green-50 p-1 text-sm">
          {links.map((link) => (
            <Link key={link.href} href={link.href} className="rounded-full px-4 py-2 font-medium text-green-800 transition hover:bg-white">
              {link.label}
            </Link>
          ))}
        </nav>
      </div>
    </header>
  );
}
