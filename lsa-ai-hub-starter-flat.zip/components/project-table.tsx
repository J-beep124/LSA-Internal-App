import type { Project } from '@/lib/data';

export function ProjectTable({ items }: { items: Project[] }) {
  return (
    <div className="card overflow-hidden">
      <table className="min-w-full divide-y divide-green-100 text-sm">
        <thead className="bg-green-50">
          <tr>
            <th className="px-4 py-3 text-left font-semibold text-slate-700">Project</th>
            <th className="px-4 py-3 text-left font-semibold text-slate-700">Division</th>
            <th className="px-4 py-3 text-left font-semibold text-slate-700">Owner</th>
            <th className="px-4 py-3 text-left font-semibold text-slate-700">Status</th>
            <th className="px-4 py-3 text-left font-semibold text-slate-700">Due</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-green-50 bg-white">
          {items.map((project) => (
            <tr key={project.id}>
              <td className="px-4 py-4">
                <p className="font-semibold text-brand-dark">{project.title}</p>
                <p className="mt-1 text-slate-500">{project.summary}</p>
              </td>
              <td className="px-4 py-4 text-slate-600">{project.division}</td>
              <td className="px-4 py-4 text-slate-600">{project.owner}</td>
              <td className="px-4 py-4">
                <span className="badge">{project.status}</span>
              </td>
              <td className="px-4 py-4 text-slate-600">{project.dueDate}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
