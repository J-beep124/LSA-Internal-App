export function SectionHeading({ eyebrow, title, description }: { eyebrow: string; title: string; description: string }) {
  return (
    <div className="mb-6">
      <p className="text-sm font-semibold uppercase tracking-[0.18em] text-green-700">{eyebrow}</p>
      <h2 className="mt-2 text-3xl font-bold text-brand-dark">{title}</h2>
      <p className="mt-3 max-w-3xl text-sm text-slate-600">{description}</p>
    </div>
  );
}
