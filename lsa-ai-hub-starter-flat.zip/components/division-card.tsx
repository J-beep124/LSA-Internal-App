import type { Division } from '@/lib/data';

export function DivisionCard({ division }: { division: Division }) {
  return (
    <article className="card p-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="badge">{division.priority}</p>
          <h3 className="mt-3 text-xl font-semibold text-brand-dark">{division.name}</h3>
          <p className="mt-2 text-sm text-slate-600">{division.summary}</p>
        </div>
      </div>
      <div className="mt-5 grid gap-4 md:grid-cols-2">
        <div>
          <p className="text-sm font-semibold text-slate-900">Core workflows</p>
          <ul className="mt-2 space-y-2 text-sm text-slate-600">
            {division.workflows.map((workflow) => (
              <li key={workflow}>• {workflow}</li>
            ))}
          </ul>
        </div>
        <div>
          <p className="text-sm font-semibold text-slate-900">AI assists</p>
          <ul className="mt-2 space-y-2 text-sm text-slate-600">
            {division.aiIdeas.map((idea) => (
              <li key={idea}>• {idea}</li>
            ))}
          </ul>
        </div>
      </div>
    </article>
  );
}
