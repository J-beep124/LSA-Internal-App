import type { Reminder } from '@/lib/data';

export function ReminderList({ items }: { items: Reminder[] }) {
  return (
    <div className="grid gap-4">
      {items.map((reminder) => (
        <div key={reminder.id} className="card p-5">
          <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
            <div>
              <p className="text-lg font-semibold text-brand-dark">{reminder.title}</p>
              <p className="mt-1 text-sm text-slate-600">{reminder.area} · {reminder.assignee}</p>
            </div>
            <div className="flex items-center gap-3">
              <span className="badge">{reminder.priority}</span>
              <p className="text-sm text-slate-500">{reminder.due}</p>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
