export type Division = {
  slug: string;
  name: string;
  summary: string;
  priority: 'Now' | 'Next' | 'Later';
  workflows: string[];
  aiIdeas: string[];
};

export type Project = {
  id: string;
  title: string;
  division: string;
  owner: string;
  status: 'Planned' | 'In progress' | 'Blocked' | 'Done';
  dueDate: string;
  summary: string;
};

export type Reminder = {
  id: string;
  title: string;
  assignee: string;
  area: string;
  due: string;
  priority: 'Low' | 'Medium' | 'High';
};

export const divisions: Division[] = [
  {
    slug: 'customer-leads',
    name: 'Customer & Lead Handling',
    summary: 'Capture phone, web and email enquiries with faster responses and better follow-up.',
    priority: 'Now',
    workflows: ['Website enquiries', 'After-hours AI assistant', 'Email triage', 'Lead assignment'],
    aiIdeas: ['Suggested replies', 'Lead summaries', 'After-hours chatbot', 'Call support scripting']
  },
  {
    slug: 'marketing',
    name: 'Marketing & Demand Generation',
    summary: 'Turn content planning, SEO and campaign execution into a repeatable engine.',
    priority: 'Now',
    workflows: ['Content calendar', 'Landing pages', 'Social posting', 'Campaign tracking'],
    aiIdeas: ['Content briefs', 'SEO outlines', 'Email drafts', 'Campaign performance summaries']
  },
  {
    slug: 'growers',
    name: 'Grower Management',
    summary: 'Centralise grower history, visits, issues, opportunities and AusGAP reporting support.',
    priority: 'Next',
    workflows: ['Visit agendas', 'Communication history', 'Compliance reporting', 'Opportunities log'],
    aiIdeas: ['Visit prep notes', 'Issue summaries', 'Compliance reminders', 'Risk flags']
  },
  {
    slug: 'operations',
    name: 'Operations & Purchasing',
    summary: 'Track ordering, packaging, freight, purchasing and margin leaks from one place.',
    priority: 'Now',
    workflows: ['Order intake', 'Freight planning', 'Packaging checks', 'Purchase approvals'],
    aiIdeas: ['Demand forecasting', 'Price comparisons', 'Issue categorisation', 'Ops weekly summary']
  },
  {
    slug: 'rnd',
    name: 'R&D and Product Intelligence',
    summary: 'Store weekly trial images, input data and variety-specific learnings for long-term advantage.',
    priority: 'Next',
    workflows: ['Trial photos', 'Input logging', 'Observation notes', 'Variety reporting'],
    aiIdeas: ['Photo summaries', 'Trend spotting', 'Variety comparisons', 'Report drafts']
  },
  {
    slug: 'people',
    name: 'Staff Workflow & Leadership',
    summary: 'Run weekly priorities, reminders, leave visibility, safety reporting and leadership rhythm.',
    priority: 'Now',
    workflows: ['Weekly priorities', 'Safety issues', 'Leave calendar', 'Development ideas'],
    aiIdeas: ['Agenda builder', 'Reminder suggestions', 'Issue clustering', 'Leadership summaries']
  }
];

export const projects: Project[] = [
  {
    id: 'LSA-001',
    title: 'Lead intake dashboard',
    division: 'Customer & Lead Handling',
    owner: 'Kim',
    status: 'In progress',
    dueDate: '2026-05-01',
    summary: 'Unify website, phone and email leads into one actionable queue.'
  },
  {
    id: 'LSA-002',
    title: 'Weekly management rhythm',
    division: 'Staff Workflow & Leadership',
    owner: 'Leadership Team',
    status: 'Planned',
    dueDate: '2026-05-08',
    summary: 'Monday agenda, top priorities and weekly accountability workflow.'
  },
  {
    id: 'LSA-003',
    title: 'Grower visit prep module',
    division: 'Grower Management',
    owner: 'Joe',
    status: 'Planned',
    dueDate: '2026-05-15',
    summary: 'Generate visit agendas with grower summaries, issues and opportunities.'
  },
  {
    id: 'LSA-004',
    title: 'R&D photo timeline',
    division: 'R&D and Product Intelligence',
    owner: 'R&D',
    status: 'Blocked',
    dueDate: '2026-05-20',
    summary: 'Weekly trial plot photo upload and variety comparison timeline.'
  }
];

export const reminders: Reminder[] = [
  {
    id: 'R-1',
    title: 'Review after-hours enquiry flow',
    assignee: 'Kim',
    area: 'Customer & Lead Handling',
    due: 'Today, 4:30 PM',
    priority: 'High'
  },
  {
    id: 'R-2',
    title: 'Check purchase pricing on freight consumables',
    assignee: 'Operations',
    area: 'Operations & Purchasing',
    due: 'Tomorrow, 10:00 AM',
    priority: 'Medium'
  },
  {
    id: 'R-3',
    title: 'Prepare next grower visit agenda',
    assignee: 'Joe',
    area: 'Grower Management',
    due: 'Thursday, 8:00 AM',
    priority: 'High'
  },
  {
    id: 'R-4',
    title: 'Upload weekly trial plot photos',
    assignee: 'R&D',
    area: 'R&D and Product Intelligence',
    due: 'Friday, 3:00 PM',
    priority: 'Medium'
  }
];

export const aiPlaybooks = [
  'Answer staff questions using an internal LSA knowledge base.',
  'Summarise grower issues before a visit.',
  'Draft marketing content and campaign copy.',
  'Turn safety or operational logs into prioritised actions.',
  'Create weekly leadership agendas from active projects and reminders.'
];
