import { ReminderList } from '@/components/reminder-list';
import { SectionHeading } from '@/components/section-heading';
import { reminders } from '@/lib/data';

export default function RemindersPage() {
  return (
    <div>
      <SectionHeading
        eyebrow="Reminders"
        title="Action list and follow-ups"
        description="This page can later connect to email, push notifications, leave calendars and recurring operational reminders."
      />
      <ReminderList items={reminders} />
    </div>
  );
}
