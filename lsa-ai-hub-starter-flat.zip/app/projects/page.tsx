import { ProjectTable } from '@/components/project-table';
import { SectionHeading } from '@/components/section-heading';
import { projects } from '@/lib/data';

export default function ProjectsPage() {
  return (
    <div>
      <SectionHeading
        eyebrow="Projects"
        title="Track work across the business"
        description="This page is the starting point for project tracking. A next step would be role permissions, task comments and file attachments."
      />
      <ProjectTable items={projects} />
    </div>
  );
}
