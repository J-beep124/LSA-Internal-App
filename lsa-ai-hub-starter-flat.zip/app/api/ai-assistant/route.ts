import { NextResponse } from 'next/server';

export async function POST(request: Request) {
  const body = await request.json().catch(() => ({}));
  const prompt = typeof body.prompt === 'string' ? body.prompt : 'No prompt provided';

  return NextResponse.json({
    ok: true,
    message: 'Starter endpoint only. Replace this mocked response with OpenAI or another model provider.',
    prompt,
    suggestions: [
      'Summarise active grower issues before this week\'s visits.',
      'Draft the Monday leadership agenda based on open projects.',
      'Turn incoming leads into priority follow-up tasks.'
    ]
  });
}
