import './globals.css';
import type { Metadata } from 'next';
import { Navigation } from '@/components/navigation';

export const metadata: Metadata = {
  title: 'LSA AI Hub',
  description: 'Starter operations platform for Lawn Solutions Australia'
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <div className="min-h-screen bg-[linear-gradient(180deg,#eef7ef_0%,#f7faf7_30%,#ffffff_100%)]">
          <Navigation />
          <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">{children}</main>
        </div>
      </body>
    </html>
  );
}
