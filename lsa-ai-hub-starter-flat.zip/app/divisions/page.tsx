import { DivisionCard } from '@/components/division-card';
import { SectionHeading } from '@/components/section-heading';
import { divisions } from '@/lib/data';

export default function DivisionsPage() {
  return (
    <div>
      <SectionHeading
        eyebrow="Divisions"
        title="LSA modules by business area"
        description="Each area can become its own module while still living inside a single platform. This lets you launch quickly, then expand in stages."
      />
      <div className="grid gap-6 lg:grid-cols-2">
        {divisions.map((division) => (
          <DivisionCard key={division.slug} division={division} />
        ))}
      </div>
    </div>
  );
}
