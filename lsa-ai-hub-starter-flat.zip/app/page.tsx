import Link from 'next/link';
import { DivisionCard } from '@/components/division-card';
import { ProjectTable } from '@/components/project-table';
import { ReminderList } from '@/components/reminder-list';
import { SectionHeading } from '@/components/section-heading';
import { aiPlaybooks, divisions, projects, reminders } from '@/lib/data';

export default function HomePage() {
  return (
    <div className="space-y-10">
      <section className="card overflow-hidden">
        <div className="grid gap-8 p-8 lg:grid-cols-[1.3fr_0.7fr]">
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.18em] text-green-700">Starter app for Vercel</p>
            <h2 className="mt-3 text-4xl font-bold tracking-tight text-brand-dark">A practical starting point for the LSA AI operating system</h2>
            <p className="mt-4 max-w-3xl text-base leading-7 text-slate-600">
              This scaffold turns your PowerPoint into a working internal platform concept: projects, reminders, division dashboards
              and an AI endpoint you can later connect to OpenAI, Supabase and your real business data.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Link href="/projects" className="rounded-full bg-brand-green px-5 py-3 text-sm font-semibold text-white">View projects</Link>
              <Link href="/divisions" className="rounded-full border border-green-200 bg-white px-5 py-3 text-sm font-semibold text-green-900">View divisions</Link>
            </div>
          </div>
          <div className="rounded-2xl bg-brand-dark p-6 text-white">
            <p className="text-sm font-semibold uppercase tracking-[0.18em] text-green-200">First release focus</p>
            <ul className="mt-4 space-y-3 text-sm leading-6 text-green-50">
              <li>• Staff dashboard for priorities and reminders</li>
              <li>• Division-based project tracking</li>
              <li>• AI assistant for summaries and drafting</li>
              <li>• Scalable base for grower, R&amp;D and purchasing modules</li>
            </ul>
          </div>
        </div>
      </section>

      <section>
        <SectionHeading
          eyebrow="Business modules"
          title="High-value divisions from your plan"
          description="The first version focuses on the divisions that looked most actionable in your deck: lead handling, marketing, growers, operations, R&D and staff workflow."
        />
        <div className="grid gap-6 lg:grid-cols-2">
          {divisions.map((division) => (
            <DivisionCard key={division.slug} division={division} />
          ))}
        </div>
      </section>

      <section className="grid gap-8 lg:grid-cols-[1fr_0.9fr]">
        <div>
          <SectionHeading
            eyebrow="Current work"
            title="Sample project board"
            description="Replace the seed data with a database later. For now it shows how work can be grouped across the business."
          />
          <ProjectTable items={projects} />
        </div>
        <div>
          <SectionHeading
            eyebrow="Today"
            title="Reminder feed"
            description="A simple reminders view that can later connect to roles, calendars and notifications."
          />
          <ReminderList items={reminders.slice(0, 3)} />
        </div>
      </section>

      <section className="card p-8">
        <SectionHeading
          eyebrow="AI layer"
          title="Example AI actions"
          description="The API route included in this starter returns mocked responses. Swap it for OpenAI or another model once you are ready."
        />
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {aiPlaybooks.map((playbook) => (
            <div key={playbook} className="rounded-2xl border border-green-100 bg-green-50 p-5 text-sm text-slate-700">
              {playbook}
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
